from Main.main_class import Main
from Main.main_class_demo import Demo

def run():
    x = Main()
    x.start_search()

if __name__ == "__main__":
    run()

def demo():
    x = Demo()
    x.search_for_opportunities()
